<?php
/**
 * Joomla! 3.8 module mod_custommenu
 * @author Iblesoft
 * @package Joomla
 * @subpackage Custommenu
 * Module helper
 * @license GNU/GPL
 * This module structure created by madan chunchu.
 */
// no direct access
defined('_JEXEC') or die('Restricted access');   

class modCustommenuHelper
{
    //get account Id
    function getHello( $params )
    {
	}		
}
?>